jQuery(document).ready(function () {
//Code starts here...

})
